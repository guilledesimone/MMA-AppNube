#!/usr/bin/env python3
import warnings
warnings.filterwarnings('ignore')

import numpy as np

from flask import Flask, request, json, jsonify

import json
import os
import pickle

import predictions as pr

app = Flask(__name__)

@app.route("/")
def hello():
    return jsonify(message="Hello! I'm another Iris Classifier")


@app.route('/classify', methods=['GET'])
def classify():
    """
        Churn rate based on:
    """
    # Get the url params.
    Dependent_count = request.args.get('Dependent_count')
    Months_Inactive_12_mon = request.args.get('Months_Inactive_12_mon')
    Contacts_Count_12_mon = request.args.get('Contacts_Count_12_mon')
    Total_Trans_Amt  = request.args.get('Total_Trans_Amt')
    Total_Ct_Chng_Q4_Q1 = request.args.get('Total_Ct_Chng_Q4_Q1')
    Avg_Utilization_Ratio = request.args.get('Avg_Utilization_Ratio')
    sample = [Dependent_count,Months_Inactive_12_mon,Contacts_Count_12_mon,Total_Trans_Amt,Total_Ct_Chng_Q4_Q1,Avg_Utilization_Ratio]

    # Validations 101
    if None in sample:
        return jsonify(message='Missing some measure'), 404

    for measure in sample:
        try:
            float(measure)
        except ValueError:
            return jsonify(message='Some measure is not a float'), 404

    return jsonify(pr.predict(sample))


if __name__ == '__main__':    
    app.run(host='0.0.0.0', debug=True) 